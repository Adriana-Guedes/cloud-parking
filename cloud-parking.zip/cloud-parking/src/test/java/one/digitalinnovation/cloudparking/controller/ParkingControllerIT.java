package one.digitalinnovation.cloudparking.controller;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;


@SpringBootTest
public class ParkingControllerIT {
	
	
	@Test
	void findAll() {
		
	}
	
	@Test
	void create() {
		
	}

}
