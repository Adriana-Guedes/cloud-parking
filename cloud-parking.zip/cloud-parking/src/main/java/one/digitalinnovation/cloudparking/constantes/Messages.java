package one.digitalinnovation.cloudparking.constantes;

public class Messages {
	
	
	

	//ALTERAÇÕES DE NOME PARA CADA CLASSE RESSOURCE
	
	public static final String SWAGGER_TAG_PARKING_ENDPOINT = "PARKING CONTROLLER";

	
	
	
	//DESCRIÇÃO GERAL PARA OS ENDEPOINTS - RESSOURCE
	public static final String SWAGGER_GET_ALL = "Retorno de todos os registro";
	public static final String SWAGGER_GET = "Retorna um registro por id";
	public static final String SWAGGER_INSERT = "Insere um novo registro";
	public static final String SWAGGER_DELETE = "Remove um registro por id";
	public static final String SWAGGER_UPDATE = "Atualiza um registro por id";

	
	
	

}
